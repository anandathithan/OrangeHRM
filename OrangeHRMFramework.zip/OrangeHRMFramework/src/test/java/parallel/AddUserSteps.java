//package parallel;
//
//import org.testng.Assert;
//
//import com.pages.AdminLoginPage;
//import com.qa.factory.DriverFactory;
//
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//public class AddUserSteps {
//
//	private static String title;
//	private AdminLoginPage AdminloginPage = new AdminLoginPage(DriverFactory.getDriver());
//
//	@Given("Navigate to Users Page")
//	public void navigate_to_users_page() {
//	  
//	}
//
//	@When("Add a User with his details")
//	public void add_a_user_with_his_details() {
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new io.cucumber.java.PendingException();
//	}
//
//	@Then("Validate User is created")
//	public void validate_user_is_created() {
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new io.cucumber.java.PendingException();
//	}
//
//}
