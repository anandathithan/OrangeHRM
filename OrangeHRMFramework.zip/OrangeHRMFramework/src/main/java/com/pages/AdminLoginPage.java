package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class AdminLoginPage {


	
	private WebDriver driver;

	// 1. By Locators: OR
	private By username = By.id("txtUsername");
	private By password = By.id("txtPassword");
	private By login = By.id("btnLogin");
	private By adminTab = By.id("menu_admin_viewAdminModule");
	private By userManagementTab = By.id("menu_admin_UserManagement");
	private By users = By.id("menu_admin_viewSystemUsers");
	private By addBtn = By.id("btnAdd");
	

	// 2. Constructor of the page class:
	public AdminLoginPage(WebDriver driver) {
		this.driver = driver;
	}

	// 3. page actions: features(behavior) of the page the form of methods:

	public String getHomePageTitle() {
		return driver.getTitle();
	}

	public void enterUserName(String usernameAdmin) {
		driver.findElement(username).sendKeys(usernameAdmin);
	}

	public void enterPassword(String pwd) {
		driver.findElement(password).sendKeys(pwd);
	}

	public void btnlogin() {
		driver.findElement(login).click();
		//return new AddUserPage(driver);
	}
  
	public void clickSignOut() {
	//	driver.findElement(signOut).click();
	}
	
    public void addNewUser()
    {
    	driver.findElement(adminTab).click();
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(userManagementTab)).perform();
		driver.findElement(users).click();
		driver.findElement(addBtn).click();
    }
}
