package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class AddUserPage {

	private WebDriver driver;

	// 1. By Locators: OR
	private By adminTab = By.id("menu_admin_viewAdminModule");
	private By userManagementTab = By.id("menu_admin_UserManagement");
	private By users = By.id("menu_admin_viewSystemUsers");
	private By addBtn = By.id("btnAdd");
	

	// 2. Constructor of the page class:
	public AddUserPage(WebDriver driver) {
		this.driver = driver;
	}

	// 3. page actions: features(behavior) of the page the form of methods:

	public void NaviateToUsersPage() {
		driver.findElement(adminTab).click();
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(userManagementTab)).perform();
		driver.findElement(users).click();
		driver.findElement(addBtn).click();
	}

	
}
